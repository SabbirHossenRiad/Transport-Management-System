class AppStrings{
  static const String getStartedText='Start your journey with us';
}