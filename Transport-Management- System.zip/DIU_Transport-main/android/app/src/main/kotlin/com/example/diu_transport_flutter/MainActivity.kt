package com.example.diu_transport_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
